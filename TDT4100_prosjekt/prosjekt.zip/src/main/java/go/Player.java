package go;

public enum Player {        //enkel ENUM for å skille mellom svart og hvit spiller

    BLACK,
    WHITE

}
